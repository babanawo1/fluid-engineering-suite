import React, { useState, useMemo } from 'react';
import {
  Activity,
  Flame,
  Layers,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Info,
  ChevronRight,
  Calculator,
  Compass,
  ArrowRight,
  TrendingDown,
  Gauge
} from 'lucide-react';
import {
  Fluid,
  Pipe,
  ConductionWall,
  NewtonCoolingSystem,
  PREDEFINED_FLUIDS
} from './engineering.ts';

// Synthetic Sample Rock Data
const SAMPLE_ROCK_DATA = [
  { sampleId: "CORE-001", porosity: 18.4, permeability: 124.5, density: 2320.1, depth: 2410.5 },
  { sampleId: "CORE-002", porosity: 12.1, permeability: 14.2, density: 2450.6, depth: 2412.0 },
  { sampleId: "CORE-003", porosity: 22.5, permeability: 450.8, density: 2280.4, depth: 2414.2 },
  { sampleId: "CORE-004", porosity: 8.5, permeability: 1.2, density: 2560.2, depth: 2416.8 },
  { sampleId: "CORE-005", porosity: 15.7, permeability: 52.3, density: 2380.0, depth: 2418.5 },
  { sampleId: "CORE-006", porosity: 19.8, permeability: 210.4, density: 2310.8, depth: 2420.0 },
  { sampleId: "CORE-007", porosity: 14.3, permeability: 31.7, density: 2410.2, depth: 2422.3 },
  { sampleId: "CORE-008", porosity: 11.2, permeability: 8.9, density: 2475.0, depth: 2424.1 },
  { sampleId: "CORE-009", porosity: 24.1, permeability: 620.0, density: 2240.5, depth: 2426.0 },
  { sampleId: "CORE-010", porosity: 16.8, permeability: 78.4, density: 2360.3, depth: 2428.2 },
  { sampleId: "CORE-011", porosity: 7.2, permeability: 0.4, density: 2590.1, depth: 2430.5 },
  { sampleId: "CORE-012", porosity: 21.0, permeability: 310.5, density: 2295.4, depth: 2432.0 },
  { sampleId: "CORE-013", porosity: 13.6, permeability: 22.1, density: 2430.7, depth: 2434.4 },
  { sampleId: "CORE-014", porosity: 17.9, permeability: 105.0, density: 2335.2, depth: 2436.1 },
  { sampleId: "CORE-015", porosity: 20.4, permeability: 265.8, density: 2305.0, depth: 2438.0 },
  { sampleId: "CORE-016", porosity: 9.8, permeability: 3.5, density: 2530.8, depth: 2440.2 },
  { sampleId: "CORE-017", porosity: 23.2, permeability: 512.0, density: 2260.1, depth: 2442.5 },
  { sampleId: "CORE-018", porosity: 15.1, permeability: 44.2, density: 2395.6, depth: 2444.0 },
  { sampleId: "CORE-019", porosity: 10.5, permeability: 6.1, density: 2490.4, depth: 2446.3 },
  { sampleId: "CORE-020", porosity: 18.9, permeability: 145.2, density: 2315.0, depth: 2448.1 },
  { sampleId: "CORE-021", porosity: 25.3, permeability: 780.4, density: 2220.0, depth: 2450.0 },
  { sampleId: "CORE-022", porosity: 6.5, permeability: 0.2, density: 2610.5, depth: 2452.4 },
  { sampleId: "CORE-023", porosity: 14.8, permeability: 38.9, density: 2400.2, depth: 2454.1 },
  { sampleId: "CORE-024", porosity: 19.2, permeability: 185.0, density: 2322.6, depth: 2456.0 },
  { sampleId: "CORE-025", porosity: 22.1, permeability: 390.1, density: 2275.3, depth: 2458.2 },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'pipe' | 'heat' | 'rock'>('home');

  // --- Module A: Pipe Flow State ---
  const [fluidKey, setFluidKey] = useState<string>('Water (20°C)');
  const [customFluidName, setCustomFluidName] = useState<string>('Custom Fluid');
  const [densityInput, setDensityInput] = useState<number>(998.2);
  const [viscosityInput, setViscosityInput] = useState<number>(0.001002);
  const [diameter, setDiameter] = useState<number>(0.05); // 50 mm
  const [length, setLength] = useState<number>(100.0);
  const [roughness, setRoughness] = useState<number>(0.000045);
  const [flowRate, setFlowRate] = useState<number>(0.004); // m3/s

  const handleFluidChange = (name: string) => {
    setFluidKey(name);
    if (name in PREDEFINED_FLUIDS) {
      setDensityInput(PREDEFINED_FLUIDS[name].density);
      setViscosityInput(PREDEFINED_FLUIDS[name].dynamicViscosity);
    }
  };

  // Compute Pipe Hydraulics
  const currentFluid = useMemo(() => {
    try {
      return new Fluid(fluidKey === 'custom' ? customFluidName : fluidKey, densityInput, viscosityInput);
    } catch {
      return null;
    }
  }, [fluidKey, customFluidName, densityInput, viscosityInput]);

  const currentPipe = useMemo(() => {
    try {
      return new Pipe(diameter, length, roughness);
    } catch {
      return null;
    }
  }, [diameter, length, roughness]);

  const hydraulicResults = useMemo(() => {
    if (!currentFluid || !currentPipe || flowRate < 0) return null;
    const v = currentPipe.velocity(flowRate);
    const re = currentPipe.reynoldsNumber(flowRate, currentFluid);
    const regime = currentPipe.flowRegime(re);
    const f = currentPipe.frictionFactor(re);
    const dp = currentPipe.pressureDrop(flowRate, currentFluid);
    const hf = currentPipe.headLoss(flowRate, currentFluid);
    return {
      area: currentPipe.crossSectionalArea,
      velocity: v,
      reynolds: re,
      regime,
      frictionFactor: f,
      pressureDropPa: dp,
      pressureDropKPa: dp / 1000.0,
      headLossM: hf,
      relativeRoughness: currentPipe.relativeRoughness
    };
  }, [currentFluid, currentPipe, flowRate]);

  // Sweep calculation for ΔP vs Q
  const dpCurveData = useMemo(() => {
    if (!currentFluid || !currentPipe) return [];
    const maxQ = Math.max(flowRate * 2, 0.01);
    const points = [];
    const steps = 30;
    for (let i = 0; i <= steps; i++) {
      const qVal = (i / steps) * maxQ;
      const dp = currentPipe.pressureDrop(qVal, currentFluid) / 1000.0;
      points.push({ q: qVal, dp });
    }
    return points;
  }, [currentFluid, currentPipe, flowRate]);

  // --- Module B: Heat Transfer State ---
  const [heatSubTab, setHeatSubTab] = useState<'conduction' | 'cooling'>('conduction');
  // Conduction
  const [condK, setCondK] = useState<number>(45.0);
  const [condThickness, setCondThickness] = useState<number>(0.15);
  const [condArea, setCondArea] = useState<number>(5.0);
  const [condTHot, setCondTHot] = useState<number>(120.0);
  const [condTCold, setCondTCold] = useState<number>(25.0);

  const conductionResults = useMemo(() => {
    try {
      const wall = new ConductionWall(condK, condThickness, condArea);
      const deltaT = condTHot - condTCold;
      if (deltaT < 0) return { error: "Hot temperature must be greater than cold temperature" };
      const qDot = wall.heatRate(condTHot, condTCold);
      const flux = wall.heatFlux(condTHot, condTCold);
      return {
        rTh: wall.thermalResistance,
        deltaT,
        qDotW: qDot,
        qDotKW: qDot / 1000.0,
        flux
      };
    } catch (e: any) {
      return { error: e.message };
    }
  }, [condK, condThickness, condArea, condTHot, condTCold]);

  // Cooling
  const [coolT0, setCoolT0] = useState<number>(95.0);
  const [coolTInf, setCoolTInf] = useState<number>(22.0);
  const [coolTTarget, setCoolTTarget] = useState<number>(45.0);
  const [coolKc, setCoolKc] = useState<number>(0.015);

  const coolingResults = useMemo(() => {
    try {
      const system = new NewtonCoolingSystem(coolT0, coolTInf, coolKc);
      const tTarget = system.timeToTemperature(coolTTarget);
      
      // Generate sample curve
      const maxT = Math.max(tTarget * 1.5, 5.0 / coolKc);
      const curve = [];
      const steps = 30;
      for (let i = 0; i <= steps; i++) {
        const t = (i / steps) * maxT;
        const temp = system.temperatureAtTime(t);
        curve.push({ t, temp });
      }

      return {
        timeToTargetSec: tTarget,
        timeToTargetMin: tTarget / 60.0,
        curve,
        maxT
      };
    } catch (e: any) {
      return { error: e.message };
    }
  }, [coolT0, coolTInf, coolTTarget, coolKc]);

  // --- Module C: Rock & Fluid State ---
  const [poroFilter, setPoroFilter] = useState<number>(10.0);
  const filteredRocks = useMemo(() => {
    return SAMPLE_ROCK_DATA.filter(r => r.porosity >= poroFilter);
  }, [poroFilter]);

  const rockStats = useMemo(() => {
    if (filteredRocks.length === 0) return null;
    const porosities = filteredRocks.map(r => r.porosity);
    const perms = filteredRocks.map(r => r.permeability);
    const avgPoro = porosities.reduce((a, b) => a + b, 0) / porosities.length;
    const avgPerm = perms.reduce((a, b) => a + b, 0) / perms.length;
    const maxPerm = Math.max(...perms);
    const minPerm = Math.min(...perms);
    return { avgPoro, avgPerm, maxPerm, minPerm, count: filteredRocks.length };
  }, [filteredRocks]);

  // CSV Exporters
  const downloadPipeCSV = () => {
    if (!dpCurveData || !currentPipe || !currentFluid) return;
    const headers = "flow_rate_m3_s,velocity_m_s,reynolds_number,friction_factor,pressure_drop_Pa,pressure_drop_kPa,head_loss_m\n";
    const rows = dpCurveData.map(pt => {
      const v = currentPipe.velocity(pt.q);
      const re = currentPipe.reynoldsNumber(pt.q, currentFluid);
      const f = currentPipe.frictionFactor(re);
      const dpPa = currentPipe.pressureDrop(pt.q, currentFluid);
      const hf = currentPipe.headLoss(pt.q, currentFluid);
      return `${pt.q.toFixed(6)},${v.toFixed(4)},${re.toFixed(1)},${f.toFixed(6)},${dpPa.toFixed(2)},${(dpPa / 1000).toFixed(4)},${hf.toFixed(4)}`;
    }).join("\n");

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pipe_flow_${currentFluid.name.replace(/\s+/g, '_').toLowerCase()}.csv`;
    a.click();
  };

  const downloadRockCSV = () => {
    const headers = "Sample_ID,Porosity_percent,Permeability_mD,Density_kg_m3,Depth_m\n";
    const rows = filteredRocks.map(r => `${r.sampleId},${r.porosity},${r.permeability},${r.density},${r.depth}`).join("\n");
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `filtered_rock_data_poro_ge_${poroFilter}.csv`;
    a.click();
  };

  return (
    <div id="engineering-suite-app" className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* Top Header Navigation */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('home')}>
              <div className="bg-blue-700 text-white p-2 rounded-lg flex items-center justify-center shadow-xs">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-lg tracking-tight text-slate-900 block leading-tight">
                  Fluid Flow & Heat Transfer
                </span>
                <span className="text-xs text-slate-500 font-medium tracking-wide">
                  Engineering Suite • Python & Streamlit Compatible
                </span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex space-x-1 sm:space-x-2">
              <button
                id="nav-home"
                onClick={() => setActiveTab('home')}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center space-x-1.5 ${
                  activeTab === 'home'
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Compass className="w-4 h-4" />
                <span className="hidden sm:inline">Overview</span>
              </button>
              <button
                id="nav-pipe"
                onClick={() => setActiveTab('pipe')}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center space-x-1.5 ${
                  activeTab === 'pipe'
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Activity className="w-4 h-4 text-blue-600" />
                <span>Pipe Flow</span>
              </button>
              <button
                id="nav-heat"
                onClick={() => setActiveTab('heat')}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center space-x-1.5 ${
                  activeTab === 'heat'
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Flame className="w-4 h-4 text-amber-600" />
                <span>Heat Transfer</span>
              </button>
              <button
                id="nav-rock"
                onClick={() => setActiveTab('rock')}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center space-x-1.5 ${
                  activeTab === 'rock'
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>Rock & Fluid</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        {/* ========================================================================= */}
        {/* VIEW 1: HOME OVERVIEW & ARCHITECTURE                                     */}
        {/* ========================================================================= */}
        {activeTab === 'home' && (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 rounded-2xl text-white p-8 sm:p-10 shadow-lg relative overflow-hidden">
              <div className="relative z-10 max-w-3xl">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-200 border border-blue-400/30 mb-4">
                  University Engineering Computing Suite
                </span>
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight mb-4">
                  Fluid Flow & Heat Transfer Engineering Suite
                </h1>
                <p className="text-blue-100 text-base sm:text-lg leading-relaxed mb-6">
                  An academic software suite integrating object-oriented numerical methods,
                  first-principles boundary validation, and real-time physical simulation.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setActiveTab('pipe')}
                    className="bg-white text-blue-900 px-5 py-2.5 rounded-lg font-semibold text-sm hover:bg-blue-50 transition shadow-xs flex items-center space-x-2"
                  >
                    <span>Launch Module A (Pipe Flow)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveTab('heat')}
                    className="bg-blue-700/60 hover:bg-blue-700 text-white border border-blue-400/30 px-5 py-2.5 rounded-lg font-semibold text-sm transition flex items-center space-x-2"
                  >
                    <span>Module B (Heat Transfer)</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('rock')}
                    className="bg-blue-700/60 hover:bg-blue-700 text-white border border-blue-400/30 px-5 py-2.5 rounded-lg font-semibold text-sm transition flex items-center space-x-2"
                  >
                    <span>Module C (Rock & Fluid)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 3 Core Modules Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-blue-400 transition-all group flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 bg-blue-50 text-blue-700 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                    <Activity className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Module A: Pipe Flow Analyser</h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    Evaluate internal conduit hydraulics using Darcy-Weisbach and the implicit Colebrook-White equation with Haaland initial seeds.
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1.5 mb-6">
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>Laminar, Transitional & Turbulent regimes</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>Pressure drop ($\Delta P$) & head loss ($h_f$)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>Interactive ΔP vs. Q curve & CSV export</span>
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => setActiveTab('pipe')}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-blue-50 text-slate-800 hover:text-blue-700 font-medium rounded-lg text-sm flex items-center justify-center space-x-2 transition"
                >
                  <span>Open Pipe Flow</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-amber-400 transition-all group flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                    <Flame className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Module B: Heat Transfer</h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    Solve steady-state 1D plane conduction via Fourier's Law and transient lumped thermal capacitance decay via Newton's Cooling Law.
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1.5 mb-6">
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                      <span>Conductive thermal resistance & heat flux</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                      <span>Exact analytical time-to-target evaluation</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                      <span>Logarithmic domain singularity guard clauses</span>
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => setActiveTab('heat')}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-amber-50 text-slate-800 hover:text-amber-700 font-medium rounded-lg text-sm flex items-center justify-center space-x-2 transition"
                >
                  <span>Open Heat Transfer</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-emerald-400 transition-all group flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                    <Layers className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Module C: Rock & Fluid Dashboard</h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    Explore reservoir core sample petrophysics with dynamic porosity cut-off filtering, summary statistics, and semi-log crossplots.
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1.5 mb-6">
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Automatic porosity & permeability mapping</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Semi-log φ vs. k Kozeny-Carman crossplot</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Filtered sub-dataset export to CSV</span>
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => setActiveTab('rock')}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-emerald-50 text-slate-800 hover:text-emerald-700 font-medium rounded-lg text-sm flex items-center justify-center space-x-2 transition"
                >
                  <span>Open Rock Dashboard</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: MODULE A - PIPE FLOW ANALYSER                                    */}
        {/* ========================================================================= */}
        {activeTab === 'pipe' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Module A: Pipe Flow Analyser</h2>
              <p className="text-slate-600 text-sm">
                Compute single-phase fluid velocity, Reynolds regime, Darcy friction factor, and pressure loss across straight cylindrical conduits.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Input Control Panel */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-5">
                <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-3 flex items-center space-x-2">
                  <Calculator className="w-4 h-4 text-blue-600" />
                  <span>Fluid & Conduit Parameters</span>
                </h3>

                {/* Fluid Selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">Fluid Selection</label>
                  <select
                    value={fluidKey}
                    onChange={(e) => handleFluidChange(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    {Object.keys(PREDEFINED_FLUIDS).map((f) => (
                      <option key={f} value={f}>{f}</option>
                    ))}
                    <option value="custom">Custom Fluid</option>
                  </select>
                </div>

                {fluidKey === 'custom' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">Custom Fluid Name</label>
                    <input
                      type="text"
                      value={customFluidName}
                      onChange={(e) => setCustomFluidName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Density, ρ (kg/m³)</label>
                    <input
                      type="number"
                      value={densityInput}
                      onChange={(e) => setDensityInput(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                      step="1"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Viscosity, μ (Pa·s)</label>
                    <input
                      type="number"
                      value={viscosityInput}
                      onChange={(e) => setViscosityInput(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                      step="0.0001"
                    />
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-4 space-y-3">
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                      <span>Diameter, D (m)</span>
                      <span className="text-blue-600 font-mono">{diameter} m ({(diameter * 1000).toFixed(0)} mm)</span>
                    </div>
                    <input
                      type="range"
                      min="0.01"
                      max="0.30"
                      step="0.005"
                      value={diameter}
                      onChange={(e) => setDiameter(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                      <span>Length, L (m)</span>
                      <span className="text-blue-600 font-mono">{length} m</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="500"
                      step="5"
                      value={length}
                      onChange={(e) => setLength(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                      <span>Absolute Roughness, ε (m)</span>
                      <span className="text-blue-600 font-mono">{roughness.toFixed(6)} m</span>
                    </div>
                    <input
                      type="number"
                      value={roughness}
                      onChange={(e) => setRoughness(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                      step="0.000005"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                      <span>Flow Rate, Q (m³/s)</span>
                      <span className="text-blue-600 font-mono">{flowRate} m³/s ({(flowRate * 3600).toFixed(1)} m³/h)</span>
                    </div>
                    <input
                      type="range"
                      min="0.0001"
                      max="0.0500"
                      step="0.0005"
                      value={flowRate}
                      onChange={(e) => setFlowRate(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>
                </div>
              </div>

              {/* KPI Results & Chart Area */}
              <div className="lg:col-span-2 space-y-6">
                {hydraulicResults ? (
                  <>
                    {/* KPI Metric Cards */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                        <span className="text-xs font-medium text-slate-500 block mb-1">Mean Velocity, V</span>
                        <span className="text-xl font-bold text-slate-900">{hydraulicResults.velocity.toFixed(3)} m/s</span>
                        <span className="text-xs text-slate-400 block mt-1">V = Q / A</span>
                      </div>

                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                        <span className="text-xs font-medium text-slate-500 block mb-1">Reynolds Number</span>
                        <span className="text-xl font-bold text-slate-900">{Math.round(hydraulicResults.reynolds).toLocaleString()}</span>
                        <span className={`text-xs font-semibold block mt-1 ${
                          hydraulicResults.regime === 'Laminar' ? 'text-emerald-600' :
                          hydraulicResults.regime === 'Transitional' ? 'text-amber-600' : 'text-blue-600'
                        }`}>
                          {hydraulicResults.regime}
                        </span>
                      </div>

                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                        <span className="text-xs font-medium text-slate-500 block mb-1">Darcy Friction (f)</span>
                        <span className="text-xl font-bold text-slate-900">{hydraulicResults.frictionFactor.toFixed(5)}</span>
                        <span className="text-xs text-slate-400 block mt-1">Colebrook / 64/Re</span>
                      </div>

                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                        <span className="text-xs font-medium text-slate-500 block mb-1">Pressure Drop (ΔP)</span>
                        <span className="text-xl font-bold text-blue-700">{hydraulicResults.pressureDropKPa.toFixed(3)} kPa</span>
                        <span className="text-xs text-slate-400 block mt-1">h_f = {hydraulicResults.headLossM.toFixed(3)} m</span>
                      </div>
                    </div>

                    {hydraulicResults.regime === 'Transitional' && (
                      <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-lg text-xs flex items-center space-x-2">
                        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                        <span><strong>Warning:</strong> Flow is in the Transitional regime (2300 ≤ Re ≤ 4000). Friction factor values carry higher empirical uncertainty.</span>
                      </div>
                    )}

                    {/* Chart Container (Pure SVG Visualizer for high fidelity) */}
                    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <h4 className="font-bold text-slate-900 text-sm">Pressure Drop (ΔP) vs. Volumetric Flow Rate (Q)</h4>
                          <span className="text-xs text-slate-500">Nonlinear Darcy-Weisbach quadratic pressure scaling curve</span>
                        </div>
                        <button
                          onClick={downloadPipeCSV}
                          className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Export Curve CSV</span>
                        </button>
                      </div>

                      {/* SVG Chart */}
                      <div className="w-full h-64 bg-slate-50 border border-slate-200 rounded-lg relative p-4 flex flex-col justify-end">
                        {/* Gridlines */}
                        <div className="absolute inset-0 p-8 grid grid-rows-4 grid-cols-4 pointer-events-none opacity-20">
                          {Array.from({ length: 16 }).map((_, i) => (
                            <div key={i} className="border-t border-l border-slate-400" />
                          ))}
                        </div>

                        {/* Responsive SVG */}
                        <svg className="w-full h-full overflow-visible" viewBox="0 0 400 180" preserveAspectRatio="none">
                          {/* Curve Path */}
                          <path
                            d={(() => {
                              if (dpCurveData.length === 0) return '';
                              const maxDp = Math.max(...dpCurveData.map(d => d.dp), 1);
                              return dpCurveData.map((pt, idx) => {
                                const x = (idx / (dpCurveData.length - 1)) * 380 + 10;
                                const y = 170 - (pt.dp / maxDp) * 150;
                                return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                              }).join(' ');
                            })()}
                            fill="none"
                            stroke="#1D4ED8"
                            strokeWidth="3"
                          />

                          {/* Operating Point Indicator */}
                          {(() => {
                            const maxQ = Math.max(flowRate * 2, 0.01);
                            const maxDp = Math.max(...dpCurveData.map(d => d.dp), 1);
                            const opX = (flowRate / maxQ) * 380 + 10;
                            const opY = 170 - (hydraulicResults.pressureDropKPa / maxDp) * 150;
                            return (
                              <g>
                                <circle cx={opX} cy={opY} r="6" fill="#DC2626" />
                                <circle cx={opX} cy={opY} r="10" fill="#DC2626" fillOpacity="0.2" />
                              </g>
                            );
                          })()}
                        </svg>

                        <div className="flex justify-between text-xs text-slate-500 font-mono mt-2 pt-2 border-t border-slate-200">
                          <span>0 m³/s</span>
                          <span>Operating Point: {flowRate.toFixed(4)} m³/s (ΔP: {hydraulicResults.pressureDropKPa.toFixed(2)} kPa)</span>
                          <span>{(flowRate * 2).toFixed(4)} m³/s</span>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="bg-red-50 text-red-700 p-4 rounded-xl text-sm">
                    Invalid pipe or fluid configuration parameters. Please check values.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: MODULE B - HEAT TRANSFER CALCULATOR                              */}
        {/* ========================================================================= */}
        {activeTab === 'heat' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Module B: Heat Transfer Calculator</h2>
              <p className="text-slate-600 text-sm">
                Compute steady-state 1D conduction across planar walls and transient exponential temperature decay in lumped thermal systems.
              </p>
            </div>

            {/* Sub-tab selection */}
            <div className="flex space-x-2 border-b border-slate-200 pb-2">
              <button
                onClick={() => setHeatSubTab('conduction')}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition ${
                  heatSubTab === 'conduction' ? 'bg-amber-100 text-amber-900' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                🧱 Section B1: Flat Wall Conduction (Fourier's Law)
              </button>
              <button
                onClick={() => setHeatSubTab('cooling')}
                className={`px-4 py-2 text-sm font-semibold rounded-lg transition ${
                  heatSubTab === 'cooling' ? 'bg-amber-100 text-amber-900' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                ⏱️ Section B2: Newton's Law of Cooling (Transient)
              </button>
            </div>

            {heatSubTab === 'conduction' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Conduction Inputs */}
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
                  <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-3">
                    Conduction Parameters (Fourier's Law)
                  </h3>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Thermal Conductivity, k (W/(m·K))
                    </label>
                    <input
                      type="number"
                      value={condK}
                      onChange={(e) => setCondK(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                      step="1"
                    />
                    <span className="text-xs text-slate-400">Carbon Steel ≈ 45, Brick ≈ 0.7, Glass Wool ≈ 0.04</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Wall Thickness, L (m)</label>
                      <input
                        type="number"
                        value={condThickness}
                        onChange={(e) => setCondThickness(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                        step="0.01"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Surface Area, A (m²)</label>
                      <input
                        type="number"
                        value={condArea}
                        onChange={(e) => setCondArea(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                        step="0.5"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Hot Side Temp, T_hot (°C)</label>
                      <input
                        type="number"
                        value={condTHot}
                        onChange={(e) => setCondTHot(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                        step="5"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Cold Side Temp, T_cold (°C)</label>
                      <input
                        type="number"
                        value={condTCold}
                        onChange={(e) => setCondTCold(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                        step="5"
                      />
                    </div>
                  </div>
                </div>

                {/* Conduction Results */}
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-3 mb-4">
                      Steady-State Conduction Results
                    </h3>

                    {conductionResults && !('error' in conductionResults) ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                            <span className="text-xs text-slate-500 font-medium block">Temperature Gradient (ΔT)</span>
                            <span className="text-xl font-bold text-slate-900">{conductionResults.deltaT.toFixed(2)} °C</span>
                          </div>
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                            <span className="text-xs text-slate-500 font-medium block">Thermal Resistance (R_th)</span>
                            <span className="text-xl font-bold text-slate-900">{conductionResults.rTh.toFixed(5)} K/W</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-amber-50 p-4 rounded-xl border border-amber-200">
                            <span className="text-xs text-amber-700 font-semibold block">Heat Transfer Rate (Q̇)</span>
                            <span className="text-2xl font-black text-amber-900">{conductionResults.qDotKW.toFixed(3)} kW</span>
                            <span className="text-xs text-amber-600 block mt-1">{conductionResults.qDotW.toFixed(1)} Watts</span>
                          </div>
                          <div className="bg-amber-50 p-4 rounded-xl border border-amber-200">
                            <span className="text-xs text-amber-700 font-semibold block">Heat Flux (q'')</span>
                            <span className="text-2xl font-black text-amber-900">{conductionResults.flux.toFixed(1)} W/m²</span>
                            <span className="text-xs text-amber-600 block mt-1">q'' = Q̇ / A</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-sm">
                        {'error' in (conductionResults || {}) ? (conductionResults as any).error : "Invalid conduction parameters"}
                      </div>
                    )}
                  </div>

                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-xs text-slate-600 mt-6 font-mono">
                    Fourier's Law: Q̇ = k · A · (T_hot - T_cold) / L = ΔT / R_th
                  </div>
                </div>
              </div>
            )}

            {heatSubTab === 'cooling' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Cooling Inputs */}
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
                  <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-3">
                    Newton Cooling Inputs
                  </h3>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Initial Temperature, T0 (°C)</label>
                    <input
                      type="number"
                      value={coolT0}
                      onChange={(e) => setCoolT0(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Ambient Temperature, T_inf (°C)</label>
                    <input
                      type="number"
                      value={coolTInf}
                      onChange={(e) => setCoolTInf(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Target Temperature, T_target (°C)</label>
                    <input
                      type="number"
                      value={coolTTarget}
                      onChange={(e) => setCoolTTarget(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Cooling Constant, k_c (1/s)</label>
                    <input
                      type="number"
                      value={coolKc}
                      onChange={(e) => setCoolKc(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800"
                      step="0.001"
                    />
                  </div>
                </div>

                {/* Cooling Curve Visualizer */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base mb-2">Transient Temperature Decay Curve</h3>
                    <p className="text-xs text-slate-500 mb-4">Exponential approach to ambient asymptote</p>

                    {coolingResults && !('error' in coolingResults) ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
                            <span className="text-xs font-semibold text-emerald-700 block">Time to Reach Target (Seconds)</span>
                            <span className="text-2xl font-black text-emerald-900">{coolingResults.timeToTargetSec.toFixed(2)} s</span>
                          </div>
                          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
                            <span className="text-xs font-semibold text-emerald-700 block">Time in Minutes</span>
                            <span className="text-2xl font-black text-emerald-900">{coolingResults.timeToTargetMin.toFixed(2)} min</span>
                          </div>
                        </div>

                        {/* Transient Decay SVG Graphic */}
                        <div className="w-full h-56 bg-slate-50 border border-slate-200 rounded-lg p-4 relative flex flex-col justify-end">
                          <svg className="w-full h-full overflow-visible" viewBox="0 0 400 160" preserveAspectRatio="none">
                            {/* Ambient Asymptote Line */}
                            <line x1="0" y1="140" x2="400" y2="140" stroke="#94A3B8" strokeWidth="2" strokeDasharray="4" />

                            {/* Cooling Exponential Curve */}
                            <path
                              d={(() => {
                                const curve = coolingResults.curve;
                                const maxT = coolingResults.maxT;
                                const maxTemp = Math.max(coolT0, coolTTarget);
                                const minTemp = coolTInf;
                                const tempRange = maxTemp - minTemp || 1;

                                return curve.map((pt, idx) => {
                                  const x = (pt.t / maxT) * 380 + 10;
                                  const y = 140 - ((pt.temp - minTemp) / tempRange) * 120;
                                  return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                                }).join(' ');
                              })()}
                              fill="none"
                              stroke="#059669"
                              strokeWidth="3"
                            />

                            {/* Target Point Marker */}
                            {(() => {
                              const maxT = coolingResults.maxT;
                              const maxTemp = Math.max(coolT0, coolTTarget);
                              const minTemp = coolTInf;
                              const tempRange = maxTemp - minTemp || 1;
                              const targetX = (coolingResults.timeToTargetSec / maxT) * 380 + 10;
                              const targetY = 140 - ((coolTTarget - minTemp) / tempRange) * 120;
                              return (
                                <g>
                                  <circle cx={targetX} cy={targetY} r="6" fill="#DC2626" />
                                  <text x={targetX + 8} y={targetY - 5} fontSize="10" fill="#DC2626" fontWeight="bold">
                                    Target ({coolTTarget}°C @ {coolingResults.timeToTargetSec.toFixed(1)}s)
                                  </text>
                                </g>
                              );
                            })()}
                          </svg>
                          <div className="flex justify-between text-xs text-slate-500 font-mono mt-2 pt-2 border-t border-slate-200">
                            <span>t = 0 s ({coolT0}°C)</span>
                            <span>Ambient Asymptote T_inf = {coolTInf}°C</span>
                            <span>t = {coolingResults.maxT.toFixed(0)} s</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-sm">
                        {'error' in (coolingResults || {}) ? (coolingResults as any).error : "Invalid cooling parameters"}
                      </div>
                    )}
                  </div>

                  <div className="text-xs text-slate-500 mt-4">
                    Analytical formula: t = - (1/k_c) · ln[ (T_target - T_inf) / (T0 - T_inf) ]
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: MODULE C - ROCK & FLUID DATA DASHBOARD                          */}
        {/* ========================================================================= */}
        {activeTab === 'rock' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Module C: Rock & Fluid Data Dashboard</h2>
                <p className="text-slate-600 text-sm">
                  Petrophysical core sample data exploration with dynamic porosity cut-off filtering and semi-log permeability crossplotting.
                </p>
              </div>
              <button
                onClick={downloadRockCSV}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-sm flex items-center space-x-2 transition shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Export Filtered CSV</span>
              </button>
            </div>

            {/* Filter Slider & KPI Banner */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                    <span>Minimum Porosity Cut-Off Filter (φ ≥ threshold)</span>
                    <span className="text-emerald-700 font-bold font-mono">{poroFilter.toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min="5.0"
                    max="24.0"
                    step="0.5"
                    value={poroFilter}
                    onChange={(e) => setPoroFilter(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                </div>
              </div>

              {rockStats && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-slate-100 pt-4">
                  <div>
                    <span className="text-xs text-slate-500 block">Retained Core Samples</span>
                    <span className="text-xl font-bold text-slate-900">{rockStats.count} / {SAMPLE_ROCK_DATA.length}</span>
                    <span className="text-xs text-emerald-600 font-semibold block">
                      {((rockStats.count / SAMPLE_ROCK_DATA.length) * 100).toFixed(0)}% preserved
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Average Porosity (φ)</span>
                    <span className="text-xl font-bold text-slate-900">{rockStats.avgPoro.toFixed(2)} %</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Average Permeability (k)</span>
                    <span className="text-xl font-bold text-slate-900">{rockStats.avgPerm.toFixed(1)} mD</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Permeability Range</span>
                    <span className="text-xl font-bold text-slate-900">{rockStats.minPerm.toFixed(1)} – {rockStats.maxPerm.toFixed(1)} mD</span>
                  </div>
                </div>
              )}
            </div>

            {/* Core Data Table & Visualizer */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Semi-Log Scatter Representation */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
                <h3 className="font-bold text-slate-900 text-sm mb-1">Porosity vs. Permeability Crossplot (Semi-Log)</h3>
                <span className="text-xs text-slate-500 block mb-4">Logarithmic permeability represents pore throat distribution</span>

                <div className="w-full h-64 bg-slate-50 border border-slate-200 rounded-lg p-4 relative flex flex-col justify-end">
                  <svg className="w-full h-full overflow-visible" viewBox="0 0 300 180" preserveAspectRatio="none">
                    {/* Log Scale Grid */}
                    <line x1="0" y1="40" x2="300" y2="40" stroke="#E2E8F0" strokeWidth="1" />
                    <line x1="0" y1="90" x2="300" y2="90" stroke="#E2E8F0" strokeWidth="1" />
                    <line x1="0" y1="140" x2="300" y2="140" stroke="#E2E8F0" strokeWidth="1" />

                    {filteredRocks.map((r, i) => {
                      const x = ((r.porosity - 5) / 22) * 280 + 10;
                      // log10(k) from 0.1 (y=170) to 1000 (y=10)
                      const logK = Math.log10(Math.max(r.permeability, 0.1));
                      const y = 170 - ((logK + 1) / 4) * 160;
                      return (
                        <circle
                          key={i}
                          cx={x}
                          cy={y}
                          r="5"
                          fill="#059669"
                          stroke="#0F172A"
                          strokeWidth="1"
                          opacity="0.85"
                        />
                      );
                    })}
                  </svg>
                  <div className="flex justify-between text-xs text-slate-500 font-mono mt-2 pt-2 border-t border-slate-200">
                    <span>φ = 5%</span>
                    <span>Porosity vs. Permeability (Semi-Log)</span>
                    <span>φ = 27%</span>
                  </div>
                </div>
              </div>

              {/* Data Table */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm mb-4">Filtered Reservoir Core Samples ({filteredRocks.length} rows)</h3>
                  <div className="overflow-y-auto max-h-56 border border-slate-200 rounded-lg">
                    <table className="w-full text-left text-xs text-slate-700">
                      <thead className="bg-slate-100 text-slate-900 font-semibold sticky top-0">
                        <tr>
                          <th className="px-3 py-2">Sample ID</th>
                          <th className="px-3 py-2">Porosity (%)</th>
                          <th className="px-3 py-2">Permeability (mD)</th>
                          <th className="px-3 py-2">Depth (m)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredRocks.map((row) => (
                          <tr key={row.sampleId} className="hover:bg-slate-50">
                            <td className="px-3 py-2 font-mono font-medium text-slate-900">{row.sampleId}</td>
                            <td className="px-3 py-2 font-mono">{row.porosity.toFixed(1)}%</td>
                            <td className="px-3 py-2 font-mono">{row.permeability.toFixed(1)} mD</td>
                            <td className="px-3 py-2 font-mono text-slate-500">{row.depth.toFixed(1)} m</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
                  Synthetic petrophysical demonstration dataset calibrated for sandstone reservoir analog.
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-500">
          Fluid Flow & Heat Transfer Engineering Suite • University Engineering Computing Project
        </div>
      </footer>
    </div>
  );
}
