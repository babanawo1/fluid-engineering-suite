/**
 * Pure TypeScript Engineering Calculation Engine.
 * Client-side mirror of the Python engineering.py domain model.
 */

export interface FluidProps {
  name: string;
  density: number; // kg/m^3
  dynamicViscosity: number; // Pa·s
}

export const PREDEFINED_FLUIDS: Record<string, FluidProps> = {
  "Water (20°C)": { name: "Water (20°C)", density: 998.2, dynamicViscosity: 1.002e-3 },
  "Air (20°C, 1 atm)": { name: "Air (20°C, 1 atm)", density: 1.204, dynamicViscosity: 1.825e-5 },
  "Crude Oil (Medium, 15°C)": { name: "Crude Oil (Medium, 15°C)", density: 860.0, dynamicViscosity: 0.025 },
};

export class Fluid {
  name: string;
  density: number;
  dynamicViscosity: number;

  constructor(name: string, density: number, dynamicViscosity: number) {
    if (density <= 0) throw new Error(`Density must be > 0. Received ${density}`);
    if (dynamicViscosity <= 0) throw new Error(`Viscosity must be > 0. Received ${dynamicViscosity}`);
    this.name = name;
    this.density = density;
    this.dynamicViscosity = dynamicViscosity;
  }

  get kinematicViscosity(): number {
    return this.dynamicViscosity / this.density;
  }
}

export function frictionFactorHaaland(reynolds: number, roughness: number, diameter: number): number {
  if (reynolds <= 0) throw new Error("Reynolds number must be positive for Haaland equation");
  const relRough = (roughness / diameter) / 3.7;
  const term = Math.pow(relRough, 1.11) + (6.9 / reynolds);
  const invSqrtF = -1.8 * Math.log10(term);
  return 1.0 / (invSqrtF * invSqrtF);
}

export function frictionFactorColebrook(reynolds: number, roughness: number, diameter: number): number {
  if (reynolds <= 0) return 0;
  if (reynolds < 2300) return 64.0 / reynolds;

  // Explicit Haaland seed
  let f = frictionFactorHaaland(reynolds, roughness, diameter);

  // Newton-Raphson iteration for Colebrook-White:
  // F(f) = 1/sqrt(f) + 2*log10( eps/(3.7*D) + 2.51/(Re*sqrt(f)) ) = 0
  for (let i = 0; i < 15; i++) {
    const sqrtF = Math.sqrt(f);
    const arg = (roughness / (3.7 * diameter)) + (2.51 / (reynolds * sqrtF));
    if (arg <= 0) break;

    const val = (1.0 / sqrtF) + 2.0 * Math.log10(arg);
    const dVal_df = -0.5 * Math.pow(f, -1.5) - (2.0 / Math.LN10) * (1.0 / arg) * (2.51 / reynolds) * (-0.5 * Math.pow(f, -1.5));

    const step = val / dVal_df;
    f = f - step;
    if (Math.abs(step) < 1e-7) break;
    if (f <= 0.001 || f > 0.5) {
      return frictionFactorHaaland(reynolds, roughness, diameter);
    }
  }

  return f;
}

export class Pipe {
  diameter: number; // m
  length: number; // m
  roughness: number; // m

  constructor(diameter: number, length: number, roughness: number = 0.0) {
    if (diameter <= 0) throw new Error("Diameter must be > 0");
    if (length <= 0) throw new Error("Length must be > 0");
    if (roughness < 0) throw new Error("Roughness cannot be negative");
    this.diameter = diameter;
    this.length = length;
    this.roughness = roughness;
  }

  get crossSectionalArea(): number {
    return (Math.PI * Math.pow(this.diameter, 2)) / 4.0;
  }

  get relativeRoughness(): number {
    return this.roughness / this.diameter;
  }

  velocity(flowRate: number): number {
    if (flowRate <= 0) return 0;
    return flowRate / this.crossSectionalArea;
  }

  reynoldsNumber(flowRate: number, fluid: Fluid): number {
    const v = this.velocity(flowRate);
    if (v === 0) return 0;
    return (fluid.density * v * this.diameter) / fluid.dynamicViscosity;
  }

  flowRegime(reynolds: number): "Laminar" | "Transitional" | "Turbulent" {
    if (reynolds < 2300) return "Laminar";
    if (reynolds <= 4000) return "Transitional";
    return "Turbulent";
  }

  frictionFactor(reynolds: number): number {
    if (reynolds <= 0) return 0;
    if (reynolds < 2300) return 64.0 / reynolds;
    return frictionFactorColebrook(reynolds, this.roughness, this.diameter);
  }

  pressureDrop(flowRate: number, fluid: Fluid): number {
    if (flowRate === 0) return 0;
    const v = this.velocity(flowRate);
    const re = this.reynoldsNumber(flowRate, fluid);
    const f = this.frictionFactor(re);
    return f * (this.length / this.diameter) * (fluid.density * Math.pow(v, 2) / 2.0);
  }

  headLoss(flowRate: number, fluid: Fluid): number {
    if (flowRate === 0) return 0;
    const dp = this.pressureDrop(flowRate, fluid);
    return dp / (fluid.density * 9.81);
  }
}

export class ConductionWall {
  thermalConductivity: number;
  thickness: number;
  area: number;

  constructor(thermalConductivity: number, thickness: number, area: number) {
    if (thermalConductivity <= 0) throw new Error("Thermal conductivity must be > 0");
    if (thickness <= 0) throw new Error("Thickness must be > 0");
    if (area <= 0) throw new Error("Area must be > 0");
    this.thermalConductivity = thermalConductivity;
    this.thickness = thickness;
    this.area = area;
  }

  get thermalResistance(): number {
    return this.thickness / (this.thermalConductivity * this.area);
  }

  heatRate(tHot: number, tCold: number): number {
    if (tHot < tCold) throw new Error("Hot temperature cannot be lower than cold temperature");
    return (this.thermalConductivity * this.area * (tHot - tCold)) / this.thickness;
  }

  heatFlux(tHot: number, tCold: number): number {
    return this.heatRate(tHot, tCold) / this.area;
  }
}

export class NewtonCoolingSystem {
  tInitial: number;
  tAmbient: number;
  coolingConstant: number;

  constructor(tInitial: number, tAmbient: number, coolingConstant: number) {
    if (coolingConstant <= 0) throw new Error("Cooling constant must be > 0");
    this.tInitial = tInitial;
    this.tAmbient = tAmbient;
    this.coolingConstant = coolingConstant;
  }

  temperatureAtTime(time: number): number {
    if (time < 0) throw new Error("Time cannot be negative");
    return this.tAmbient + (this.tInitial - this.tAmbient) * Math.exp(-this.coolingConstant * time);
  }

  timeToTemperature(tTarget: number): number {
    const deltaInit = this.tInitial - this.tAmbient;
    const deltaTarget = tTarget - this.tAmbient;

    if (deltaInit === 0) throw new Error("Initial temperature equals ambient temperature");
    const ratio = deltaTarget / deltaInit;
    if (ratio <= 0) throw new Error("Target temperature crosses ambient boundary");
    if (ratio > 1.0) throw new Error("Target temperature is further from ambient than initial temperature");

    return -(1.0 / this.coolingConstant) * Math.log(ratio);
  }
}
