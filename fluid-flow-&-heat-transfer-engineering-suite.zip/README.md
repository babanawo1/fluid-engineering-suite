# Fluid Flow & Heat Transfer Engineering Suite

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.35+-FF4B4B.svg)](https://streamlit.io/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

An interactive, multi-page engineering computing software suite designed for mechanical, chemical, and petroleum engineering calculations. Built with Python, Streamlit, NumPy, SciPy, Pandas, and Plotly.

---

## 🚀 Live Demo & Deployment

* **Streamlit Community Cloud Deployment:** `YOUR_STREAMLIT_APP_URL`
* **GitHub Source Code Repository:** `YOUR_GITHUB_REPOSITORY_URL`

---

## 📚 Application Modules

### 1. 🌊 Module A: Pipe Flow Analyser (`pages/1_Pipe_Flow_Analyser.py`)
* Computes fluid velocity ($V$), Reynolds number ($Re$), and flow regime (Laminar, Transitional, Turbulent).
* Solves the implicit **Colebrook-White** turbulent friction factor equation via Brent's method with Haaland initialization.
* Calculates Darcy-Weisbach pressure drop ($\Delta P$) and head loss ($h_f$).
* Generates interactive $\Delta P \text{ vs } Q$ system performance curves with current operating point markers.
* Provides CSV export of the hydraulic operating curve.

### 2. 🔥 Module B: Heat Transfer Calculator (`pages/2_Heat_Transfer.py`)
* **Section B1 — Flat Wall Conduction:** Evaluates 1D steady-state heat rate ($\dot{Q}$) and heat flux ($q''$) using Fourier's Law with thermal resistance modeling.
* **Section B2 — Newton's Law of Cooling:** Analyzes transient lumped thermal capacity decay, computing the exact analytical time to reach target temperatures with mathematical logarithm boundary protection.
* Visualizes real-time transient temperature decay curves $T(t)$ with ambient asymptotes.

### 3. 🪨 Module C: Rock & Fluid Data Dashboard (`pages/3_Rock_Fluid_Dashboard.py`)
* Supports custom CSV file uploads and includes a 40-sample synthetic core dataset.
* Automated heuristic column detection for porosity ($\phi$) and permeability ($k$).
* Real-time sample slicing with dynamic minimum porosity cut-off filters.
* Computes summary descriptive statistics (`df.describe()`).
* Generates porosity distribution histograms and semi-log $\phi \text{ vs } k$ crossplots.
* Exports filtered datasets to CSV.

---

## 🏛️ Project Architecture & Clean OOP Design

```text
fluid-engineering-suite/
│
├── app.py                         # Main landing page & suite overview
├── engineering.py                 # Core numerical domain models & OOP classes
├── requirements.txt               # Production Python dependencies
├── README.md                      # Comprehensive academic & engineering documentation
├── .gitignore                     # Git ignore rules for Python, cache, and OS artifacts
│
├── .streamlit/
│   └── config.toml                # Streamlit theme and server configuration
│
├── pages/
│   ├── 1_Pipe_Flow_Analyser.py    # Module A: Hydraulic pipe flow calculations & Moody curves
│   ├── 2_Heat_Transfer.py         # Module B: 1D Conduction & Newton's Law of Cooling
│   └── 3_Rock_Fluid_Dashboard.py  # Module C: Petrophysical rock data analytics & porosity filters
│
├── utils/
│   ├── __init__.py                # Package marker
│   ├── validation.py              # Input validation and bounds checking functions
│   └── plotting.py                # Reusable Plotly chart generators with engineering themes
│
├── tests/
│   ├── __init__.py                # Test package marker
│   └── test_engineering.py        # Pytest suite for unit tests and edge cases
│
├── data/
│   └── sample_rock_data.csv       # Synthetic petrophysical dataset (40 rock core samples)
│
└── docs/
    ├── verification.md            # Independent manual calculation benchmarks
    ├── ai_usage.md                # Responsible AI documentation and prompt logs
    └── developer_report.md        # One-page technical insight & engineering report draft
```

---

## ⚙️ Installation & Local Setup

### 1. Clone Repository
```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd fluid-engineering-suite
```

### 2. Create and Activate Virtual Environment
* **Windows (PowerShell):**
  ```powershell
  python -m venv .venv
  .venv\Scripts\Activate.ps1
  ```
* **macOS / Linux:**
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  ```

### 3. Install Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Launch Streamlit Application
```bash
streamlit run app.py
```

---

## 🧪 Automated Testing Suite

Run the full automated test suite with `pytest`:

```bash
pytest tests/test_engineering.py -v
```

All tests verify analytical benchmark calculations, laminar/turbulent flow regimes, Fourier conduction, Newton cooling times, and physical boundary exception handling.

---

## 📖 Independent Verification

Detailed step-by-step manual hand calculations and comparison tables are documented in [`docs/verification.md`](docs/verification.md).

---

## 🤖 Responsible AI Usage

The prompt history, engineering verification, and human corrections are documented in [`docs/ai_usage.md`](docs/ai_usage.md).

---

## 🚀 Streamlit Community Cloud Deployment Guide

1. Push your repository to GitHub:
   ```bash
   git init
   git add .
   git commit -m "feat: complete fluid and heat transfer engineering suite"
   git remote add origin YOUR_GITHUB_REPOSITORY_URL
   git push -u origin main
   ```
2. Navigate to [share.streamlit.io](https://share.streamlit.io/).
3. Connect your GitHub account.
4. Select the repository, branch (`main`), and set the main file path to `app.py`.
5. Click **Deploy**.
